<img src="https://store.storeimages.cdn-apple.com/1/as-images.apple.com/is/mbp16-spaceblack-cto-hero-202410?wid=800&hei=800&fmt=jpeg&qlt=90&fit=constrain&.v=Nys1UFFBTmI1T0VnWWNyeEZhdDFYcGJldjZKNUozZEJDc2p3M25qTEh4MWVFR3BNVCtOSS9iaVo4aVVFYkF3VmJGcXNRQnFCV0w3WVRjTExvdm1ic2JGMDhKTzJlbGFQUlduM2ZXR05QelpLUXVRRkFFWTB4UUo2MmRyUXNxVys" width="200">

- **16-inch MacBook Pro - Space Black**
  - **Standard display**
  - **Apple M4 Max chip with 16‑core CPU,**
    - **40‑core GPU,**
    - **16‑core Neural Engine**
- **64GB unified memory**
- **1TB SSD storage**
- **140W USB-C Power Adapter**
- **Ports:**
  - **Three Thunderbolt 5 ports,**
  - **HDMI port,**
  - **SDXC card slot,**
  - **headphone jack,**
  - **MagSafe 3 port**
- **Backlit Magic Keyboard with Touch ID - US English**

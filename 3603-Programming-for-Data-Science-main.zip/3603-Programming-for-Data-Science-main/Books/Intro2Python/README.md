[▶️ Open in Colab](https://colab.research.google.com/github/rugbyprof/3603-Programming-for-Data-Science/blob/main/Books/Intro2Python)

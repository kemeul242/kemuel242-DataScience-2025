## Books

Source: https://github.com/jakevdp

|                                  |                                   |
| :------------------------------: | :-------------------------------: |
| <img src="pdsh.png" width="150"> | <img src="awtop.png" width="130"> |

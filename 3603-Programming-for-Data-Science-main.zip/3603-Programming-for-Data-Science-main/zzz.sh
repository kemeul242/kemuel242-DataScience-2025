mkdir -p Assignments/07-Working_with_Data/
touch Assignments/07-Working_with_Data/01-lists_dicts_and_tuples.ipynb
touch Assignments/07-Working_with_Data/02-pandas_series_and_dataframes.ipynb
touch Assignments/07-Working_with_Data/03-loading_and_exploring_data.ipynb
touch Assignments/07-Working_with_Data/04-indexing_and_selection.ipynb
touch Assignments/07-Working_with_Data/05-basic_cleaning.ipynb
touch Assignments/07-Working_with_Data/06-column_operations.ipynb
touch Assignments/07-Working_with_Data/07-sorting_and_filtering.ipynb
touch Assignments/07-Working_with_Data/08-pandas_wrangle_lab.ipynb
touch Assignments/07-Working_with_Data/Working_with_Data_Quiz.ipynb
touch Assignments/07-Working_with_Data/glossary.md
touch Assignments/07-Working_with_Data/README.md
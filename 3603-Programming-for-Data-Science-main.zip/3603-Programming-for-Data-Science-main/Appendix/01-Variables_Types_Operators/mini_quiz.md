# ❓ Mini Quiz: Variables, Types, and Operators

---

### 1. What’s the difference between `=` and `==`?

---

### 2. What data type is returned by this expression?

```python
type(3.0)
```

---

### 3. Fill in the blank to check if `x` is greater than or equal to 10:

```python
x ___ 10
```

---

### 4. What is the result of this expression?

```python
5 % 2
```

---

### 5. Which operator would you use to raise a number to a power?

---

### 6. What is printed?

```python
x = 5
y = 10
print(x > 3 and y < 20)
```

Answer: _______
